import login from './views/login/login.vue';
import HomePage from './views/HomePage/homePage.vue';




let routes = [
		{
		path:'/login',
        component: login,
        name: '登录'
		},
		{
		path:'/HomePage',
        component: HomePage,
        name: '首页'
		}
]
export default routes





