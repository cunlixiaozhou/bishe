<template>
	<div>
		<div class="header">
			<div id="header_main">				
					 <el-input placeholder="请输入内容" v-model="input_value" class="input-with-select">
					    <el-select v-model="select_value" slot="prepend" placeholder="请选择" style="width: 100px;">
					      <el-option label="文章" value="1">文章</el-option>
					      <el-option label="问题" value="2">问题</el-option>
					      <el-option label="动态" value="3">动态</el-option>
					    </el-select>
					    <el-button slot="append" icon="el-icon-search"></el-button>
					  </el-input>
				
					<!--<div class="nav">-->
						<ul class="navList">
							<li>首页</li>
							<li>发现</li>
							<li>消息</li>
						</ul>
					<!--</div>-->					
			</div>
			<div class="userinfo">				
						<el-dropdown trigger="hover">
							<span class="el-dropdown-link userinfo-inner"><img src="../../assets/user1.png" />admin</span>
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item>我的消息</el-dropdown-item>
								<el-dropdown-item>设置</el-dropdown-item>
								<el-dropdown-item divided @click.native="logout">退出登录</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
					
			</div>
		</div>
		<div class="page_main">
		  <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="handleSelect">
				  <el-menu-item index="1">推荐动态</el-menu-item>
				  <el-menu-item index="2">热门</el-menu-item>
				  <el-menu-item index="3">关注</el-menu-item>
		  </el-menu>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				input_value:'',
				select_value:'',
				 activeIndex: '1',
			}
		},
		methods:{
			logout: function () {
				var _this = this;
				this.$confirm('确认退出吗?', '提示', {
					//type: 'warning'
				}).then(() => {
					sessionStorage.removeItem('user');
					_this.$router.push('/login');
				}).catch(() => {

				});
			},
			handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
		}
	}
</script>

<style scoped>
	.userinfo{
				text-align: right;
				position: absolute;
				top: 0;
				right: 35px;
								
			}
			.userinfo-inner {
				display: block;
					cursor: pointer;
					color:#fff;	
					padding-top: 10px;
								
				}
		.userinfo img {
						width: 30px;
						height: 30px;
						/*border-radius: 20px;*/
						margin:10px 0px 10px 10px;
						float: right;
					}
	.header{
		height: 60px;
		line-height: 60px;
		width: 100%;
		background:#011b41;
		
	}
	.input-with-select{
		margin-left: 20px;
		margin-top: 10px;
		width: 400px;
		
	}
	#header_main{
		display: flex;
		justify-content: start;
	}
	.nav{
		height: 60px;
		line-height: 60px;
		margin: 0;
		padding: 0;
	}
	.navList{
		margin: 0;
		
	}
	.navList li{	
		display: inline-block;	
		color: white;
		list-style: none;
		width: 50px;
		height: 60px;
		text-align: center;	
		
	}
</style>