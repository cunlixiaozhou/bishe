<template>
	<div class="login">
 		<el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="100px" class="demo-ruleForm">
 			<el-form-item style="margin-right: 50px;">
 				<h2>知识问答系统</h2>
 			</el-form-item>
 			<el-form-item label="用户名" prop="account">
			    <input v-model="ruleForm2.account" auto-complete="off" placeholder="账号" id="name" class="boxShadow" autofocus>
			  </el-form-item>
			  <el-form-item label="密码" prop="checkPass">
			     <input type="password" v-model="ruleForm2.checkPass" auto-complete="off" placeholder="密码" id="passworld" class="boxShadow">
			  </el-form-item>
 			
 			<el-form-item>
			     <el-button type="primary" @click.native.prevent="handleSubmit2" :loading="logining" class="login-btn">登录</el-button>
			    <el-button @click="resetForm('ruleForm2')">注册</el-button>
		 	</el-form-item>
 		</el-form>
 	</div>
</template>

<script>
	import { requestLogin } from '../../api/api';
  export default {
   data() {
            return {
                logining: false,
                ruleForm2: {
                    account: '',
                    checkPass: ''
                },
                rules2: {
                    account: [
                        { required: true, message: '请输入账号', trigger: 'blur' },
                        //{ validator: validaePass }
                    ],
                    checkPass: [
                        { required: true, message: '请输入密码', trigger: 'blur' },
                        //{ validator: validaePass2 }
                    ]
                },
                checked: true
            };
        },
     methods: {
//          handleReset2() {
//              this.$refs.ruleForm2.resetFields();
//          },
            handleSubmit2(ev) {
                var _this = this;
                this.$refs.ruleForm2.validate((valid) => {
                    if (valid) {
                        //_this.$router.replace('/table');
                        this.logining = true;
                        //NProgress.start();
                        var loginParams = { username: this.ruleForm2.account, password: this.ruleForm2.checkPass };
                        requestLogin(loginParams).then(data => {
                            this.logining = false;
                            //NProgress.done();
                            let { msg, code, user } = data;
                            if (code !== 200) {
                                this.$message({
                                    message: msg,
                                    type: 'error'
                                });
                            } else {
                                sessionStorage.setItem('user', JSON.stringify(user));


                                this.$router.push({ path: '/HomePage' });

                                //window.location.href = 'http://127.0.0.1:8081/train/map.html';

                                // window.location.href = 'http://127.0.0.1:8081/map.html';


//                               this.$router.push({ path: '/HomePage' });
//                              window.location.href = 'http://127.0.0.1:8081/map.html';



                            }
                        });
                    } else {
                        console.log('error submit!!');
                        return false;
                    }

                });
            }
        }
  }
</script>

<style scoped>
	.login{
		width: 400px;
		height: 300px;
		border: 1px solid  red;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%,-50%);
		display: flex;
		justify-content: center;
	}
	.demo-ruleForm{
		border: 1px solid blue;
		width: 100%;
		padding-top: 10px;
		padding-right: 50px;
	}
</style>