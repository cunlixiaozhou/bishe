import Vue from 'vue'

export const USER_SIGNIN = 'USER_SIGNIN' //登录成功
export const USER_SIGNOUT = 'USER_SIGNOUT' //退出登录
export const USER_UPDATE = 'USER_UPDATE' //更新用户

let setCookie = (c_name, value, expiredays) => {
    var exdate = new Date();
    exdate.setTime(exdate.getTime() + expiredays);
    document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
}
let getCookie = (name) => {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return (arr[2]);
    else
        return null;
}
let delCookie = (name) => {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = getCookie(name);
    if (cval != null)
        document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
}

export default {

    state: JSON.parse(sessionStorage.getItem('user')) || {},
    mutations: {

        [USER_SIGNIN](state, user) {
            // 半小时
            let expireDays = 1000 * 60 * 120;

            setCookie('user', user.name, expireDays);
            //            sessionStorage.setItem('user', JSON.stringify(user))
            Object.assign(state, user)
        },
        [USER_SIGNOUT](state) {
            delCookie('user');
            //            sessionStorage.removeItem('user')
            Object.keys(state).forEach(k => Vue.delete(state, k))
        },
        //更新用户信息
        [USER_UPDATE](state) {
            var user = getCookie('user');

            Object.assign(state, {name:user})
        }
    },
    actions: {
        [USER_SIGNIN]({
            commit
        }, user) {
            commit(USER_SIGNIN, user)
        },
        [USER_SIGNOUT]({
            commit
        }) {
            commit(USER_SIGNOUT)
        },
        [USER_UPDATE]({
            commit
        }) {
            commit(USER_UPDATE)
        }

    }
}
